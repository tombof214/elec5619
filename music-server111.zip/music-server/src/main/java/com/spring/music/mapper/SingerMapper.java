package com.spring.music.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.spring.music.model.domain.Singer;
import org.springframework.stereotype.Repository;

@Repository
public interface SingerMapper extends BaseMapper<Singer> {

}
