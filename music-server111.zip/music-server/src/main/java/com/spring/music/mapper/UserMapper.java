package com.spring.music.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.spring.music.model.domain.User;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserMapper extends BaseMapper<User> {
    public User selectById(@Param("id") int id);
    public String selectByUserName(@Param("username") String username);
}
