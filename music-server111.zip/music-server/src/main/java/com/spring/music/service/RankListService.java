package com.spring.music.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.spring.music.common.R;
import com.spring.music.model.domain.RankList;
import com.spring.music.model.request.RankListRequest;

public interface RankListService extends IService<RankList> {

    R addRank(RankListRequest rankListAddRequest);

    R rankOfSongListId(Long songListId);

    R getUserRank(Long consumerId, Long songListId);

}
