package com.spring.music.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.spring.music.common.R;
import com.spring.music.model.domain.SongList;
import com.spring.music.model.request.SongListRequest;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;

public interface SongListService extends IService<SongList> {

    R addSongList(SongListRequest addSongListRequest);

    R updateSongListMsg(SongListRequest updateSongListRequest);

    R updateSongListImg(MultipartFile avatorFile, int id);

    R deleteSongList(Integer id);

    R allSongList( HttpSession session);

    R likeTitle(String title);

    R likeStyle(String style);
}
