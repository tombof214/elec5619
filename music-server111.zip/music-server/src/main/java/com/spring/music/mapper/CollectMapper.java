package com.spring.music.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.spring.music.model.domain.Collect;
import org.springframework.stereotype.Repository;

@Repository
public interface CollectMapper extends BaseMapper<Collect> {

}
