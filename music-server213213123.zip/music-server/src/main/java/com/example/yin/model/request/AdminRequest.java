package com.example.yin.model.request;

import lombok.Data;

/**
 * @Author 祝英台炸油条
 * @Time : 2022/6/6 18:44
 **/
@Data
public class AdminRequest {
    private Integer id;

    private String username;

    private String password;
}
