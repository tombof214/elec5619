package com.spring.music.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.spring.music.common.R;

import com.spring.music.mapper.UserMapper;
import com.spring.music.model.domain.User;
import com.spring.music.model.request.UserRequest;
import com.spring.music.service.UserService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import javax.servlet.http.HttpSession;
import java.nio.charset.StandardCharsets;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    /**
     * 新增用户
     */
    @Override
    public R addUser(UserRequest registryRequest) {
        if (this.existUser(registryRequest.getUsername())) {
            return R.warning("用户名已注册");
        }
        User user = new User();
        BeanUtils.copyProperties(registryRequest, user);
        //MD5加密
        String password = DigestUtils.md5DigestAsHex((registryRequest.getPassword()).getBytes(StandardCharsets.UTF_8));
        user.setPassword(password);
        if (StringUtils.isBlank(user.getPhoneNum())) {
            user.setPhoneNum(null);
        }
        if ("".equals(user.getEmail())) {
            user.setEmail(null);
        }
        try {
            if (userMapper.insert(user) > 0) {
                return R.success("注册成功");
            } else {
                return R.error("注册失败");
            }
        } catch (DuplicateKeyException e) {
            return R.fatal(e.getMessage());
        }
    }

    @Override
    public R updateUserMsg(UserRequest updateRequest) {
        User consumer = new User();
        BeanUtils.copyProperties(updateRequest, consumer);
        if (userMapper.updateById(consumer) > 0) {
            return R.success("修改成功");
        } else {
            return R.error("修改失败");
        }
    }

    @Override
    public R updatePassword(UserRequest updatePasswordRequest) {
       if (!this.verityPasswd(updatePasswordRequest.getUsername(),updatePasswordRequest.getOldPassword())) {
            return R.error("密码输入错误");
        }
        User user = new User();
        user.setId(updatePasswordRequest.getId());
        String secretPassword = DigestUtils.md5DigestAsHex((updatePasswordRequest.getPassword()).getBytes(StandardCharsets.UTF_8));
        user.setPassword(secretPassword);
        if (userMapper.updateById(user) > 0) {
            return R.success("密码修改成功");
        } else {
            return R.error("密码修改失败");
        }
    }
    @Override
    public boolean existUser(String username) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username",username);
        return userMapper.selectCount(queryWrapper) > 0;
    }

    @Override
    public boolean verityPasswd(String username, String password) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username",username);
        String secretPassword = DigestUtils.md5DigestAsHex((password).getBytes(StandardCharsets.UTF_8));
        queryWrapper.eq("password",secretPassword);
        return userMapper.selectCount(queryWrapper) > 0;
    }

    @Override
    public R allUser() {
        return R.success(null, userMapper.selectList(null));
    }

    @Override
    public R userOfId(Integer id) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("id",id);
        return R.success(null, userMapper.selectList(queryWrapper));
    }

    @Override
    public R loginStatus(UserRequest loginRequest, HttpSession session) {
        String username = loginRequest.getUsername();
        String password = loginRequest.getPassword();
        if (this.verityPasswd(username, password)) {
            session.setAttribute("username", username);
            User user = new User();
            user.setUsername(username);
            return R.success("登录成功", userMapper.selectList(new QueryWrapper<>(user)));
        } else {
            return R.error("用户名或密码错误");
        }
    }
}
