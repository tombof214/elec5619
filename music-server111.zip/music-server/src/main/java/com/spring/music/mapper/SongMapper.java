package com.spring.music.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.spring.music.model.domain.Song;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SongMapper extends BaseMapper<Song> {
    public List<String> selectSongsByFavor(@Param("favor")String favor);
    public List<String> selectRemainingSongs(String favor);

}
