package com.spring.music.controller;

import com.spring.music.common.R;
import com.spring.music.model.request.UserRequest;
import com.spring.music.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;

@RestController
@CrossOrigin
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;
    /**
     *
     * 用户注册
     */
    @PostMapping("/add")
    public R addUser(@RequestBody UserRequest registryRequest) {
        return userService.addUser(registryRequest);
    }

    /**
     *
     * 登录判断
     */
    @PostMapping("/login")
    public R login(@RequestBody UserRequest loginRequest, HttpSession session) {
        return userService.loginStatus(loginRequest, session);
    }
    /**
     *
     * 返回所有用户
     */
    @GetMapping("")
    public R allUser() {
        return userService.allUser();
    }
    /**
     *
     * 返回指定 ID 的用户
     */
    @GetMapping("/detail")
    public R userOfId(@RequestParam int id) {
        return userService.userOfId(id);
    }

    /**
     *
     * 更新用户信息
     */
    @PostMapping("/update")
    public R updateUserMsg(@RequestBody UserRequest updateRequest) {
        return userService.updateUserMsg(updateRequest);
    }

    /**
     *
     * 更新用户密码
     */
    @PostMapping("/updatePassword")
    public R updatePassword(@RequestBody UserRequest updatePasswordRequest) {
        return userService.updatePassword(updatePasswordRequest);
    }


}
