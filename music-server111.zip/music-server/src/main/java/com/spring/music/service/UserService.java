package com.spring.music.service;

import com.spring.music.common.R;
import com.spring.music.model.request.UserRequest;

import javax.servlet.http.HttpSession;

public interface UserService  {

    R addUser(UserRequest registryRequest);

    R updateUserMsg(UserRequest updateRequest);

    R updatePassword(UserRequest updatePasswordRequest);

    boolean existUser(String username);

    boolean verityPasswd(String username, String password);



    R allUser();

    R userOfId(Integer id);

    R loginStatus(UserRequest loginRequest, HttpSession session);

}
