package com.spring.music.controller;

import com.spring.music.common.R;
import com.spring.music.model.request.SongListRequest;
import com.spring.music.service.SongListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;

@RestController
@CrossOrigin
@RequestMapping("/songList")
public class SongListController {

    @Autowired
    private SongListService songListService;
    // 添加歌单
    @PostMapping("/add")
    public R addSongList(@RequestBody SongListRequest addSongListRequest) {
        return songListService.addSongList(addSongListRequest);
    }

    // 删除歌单
    @GetMapping("/songList/delete")
    public R deleteSongList(@RequestParam int id) {
        return songListService.deleteSongList(id);
    }


    @GetMapping("")
    public R allSongList(HttpSession session) {
        return songListService.allSongList(session);
    }

    // 返回标题包含文字的歌单
    @GetMapping("/likeTitleDetail")
    public R songListOfLikeTitle(@RequestParam String title) {
        return songListService.likeTitle('%' + title + '%');
    }

    // 返回指定类型的歌单
    @GetMapping("/styleDetail")
    public R songListOfStyle(@RequestParam String style) {
        return songListService.likeStyle('%' + style + '%');
    }

    // 更新歌单信息
    @PostMapping("/update")
    public R updateSongListMsg(@RequestBody SongListRequest updateSongListRequest) {
        return songListService.updateSongListMsg(updateSongListRequest);

    }

}
