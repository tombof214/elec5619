package com.spring.music.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.spring.music.common.R;
import com.spring.music.model.domain.ListSong;
import com.spring.music.model.request.ListSongRequest;

import java.util.List;

public interface ListSongService extends IService<ListSong> {

    R addListSong(ListSongRequest addListSongRequest);

    R updateListSongMsg(ListSongRequest updateListSongRequest);

    R deleteListSong(Integer songId);

    //看看这啥
    List<ListSong> allListSong();

    R listSongOfSongId(Integer songListId);
}
